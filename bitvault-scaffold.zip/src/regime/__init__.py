# Regime classification logic
