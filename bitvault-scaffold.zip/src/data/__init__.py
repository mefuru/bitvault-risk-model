# Data fetching and storage modules
