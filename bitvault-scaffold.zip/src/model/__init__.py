# GARCH, jump diffusion, and Monte Carlo simulation
