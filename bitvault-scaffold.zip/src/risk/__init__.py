# LTV calculations and risk metrics
